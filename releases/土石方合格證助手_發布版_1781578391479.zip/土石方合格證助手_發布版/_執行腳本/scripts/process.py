"""
合格證已核可檔案比對作業
- CURR_FILE: 自動取 _國土署匯出檔/ 內最新的 xlsx
- PREV_FILE: 自動取 _國土署匯出檔/archived/ 內最新的 xlsx
- Sheets: _暫存/Sheets(北竹).xlsx, _暫存/Sheets(中南).xlsx
- OUTPUT:  _已核可清單/合格證_已核可_YYYYMMDD_查詢.xlsx（執行當日日期）
"""
import sys
import glob
import os
import argparse
from pathlib import Path
from datetime import date
from openpyxl import load_workbook, Workbook
from openpyxl.styles import PatternFill

sys.stdout.reconfigure(encoding='utf-8')

_SCRIPTS_DIR = Path(__file__).resolve().parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))
from download_sheets import download_all_sheets

_parser = argparse.ArgumentParser()
_parser.add_argument('--curr', default=None, help='指定目前 xlsx 檔案完整路徑')
_parser.add_argument('--prev', default=None, help='指定比對基準 xlsx 檔案完整路徑')
_cli, _ = _parser.parse_known_args()

BASE  = str(Path(__file__).resolve().parents[2])
SRC   = BASE + r'\_國土署匯出檔'
ARCH  = SRC  + r'\archived'
TEMP  = BASE + r'\_暫存'
OUT   = BASE + r'\_已核可清單'
os.makedirs(OUT, exist_ok=True)

# ── 自動下載最新 Sheets 資料 ──────────────────────────────────────────────────
download_all_sheets()

# ── 環境檢查 ─────────────────────────────────────────────────────────────────
def check_env():
    errors = []

    if not glob.glob(os.path.join(SRC, '*.xlsx')):
        errors.append('_國土署匯出檔/ 沒有 xlsx 檔案\n  請先執行步驟 1：download_oa301.py')
    if not glob.glob(os.path.join(ARCH, '*.xlsx')):
        errors.append('_國土署匯出檔/archived/ 沒有上次的 xlsx 檔案\n  請確認前次的匯出檔已存在')

    if errors:
        print('\n[環境檢查失敗] 請修正以下問題後重新執行：\n')
        for i, e in enumerate(errors, 1):
            print(f'  {i}. {e}')
        sys.exit(1)

    print('[環境檢查] 通過\n')

check_env()


# ── 自動偵測輸入檔案 ─────────────────────────────────────────────────────────
def latest_xlsx(folder):
    files = glob.glob(os.path.join(folder, '*.xlsx'))
    if not files:
        raise FileNotFoundError(f'找不到 xlsx 檔案：{folder}')
    return max(files, key=os.path.getmtime)

CURR_FILE = _cli.curr if _cli.curr else latest_xlsx(SRC)
PREV_FILE = _cli.prev if _cli.prev else latest_xlsx(ARCH)
SHEETS_A  = TEMP + r'\Sheets(北竹).xlsx'
SHEETS_B  = TEMP + r'\Sheets(中南).xlsx'
OUTPUT    = OUT  + rf'\合格證_已核可_{date.today().strftime("%Y%m%d")}_查詢.xlsx'

print(f'本次檔案: {os.path.basename(CURR_FILE)}')
print(f'上次檔案: {os.path.basename(PREV_FILE)}')
print(f'輸出檔案: {os.path.basename(OUTPUT)}')

SHEET_NAME = '國土署-土石方'

FILL_RED   = PatternFill(fill_type='solid', fgColor='FFCCCC')
FILL_GREEN = PatternFill(fill_type='solid', fgColor='CCFFCC')

KEY_SENT = '寄出合格證至客端'


# ── 讀取 Google Sheets XLSX（含全欄合併儲存格補值）────────────────────────────

def normalize_header(h):
    return h.replace('\n', '').replace(' ', '').strip() if h else ''

def load_sheets_xlsx(path):
    fname = os.path.basename(path)
    if not os.path.exists(path):
        raise FileNotFoundError(f'找不到 Sheets 檔案：{path}\n請先下載並放置於 _暫存/ 資料夾')

    wb = load_workbook(path, data_only=True)

    if SHEET_NAME not in wb.sheetnames:
        raise ValueError(f'[{fname}] 找不到工作表「{SHEET_NAME}」，現有：{wb.sheetnames}')

    ws = wb[SHEET_NAME]

    merge_map = {}
    for merged_range in ws.merged_cells.ranges:
        top_val = ws.cell(merged_range.min_row, merged_range.min_col).value
        if isinstance(top_val, float) and top_val == int(top_val):
            top_val = int(top_val)
        fill_val = str(top_val).strip() if top_val is not None else ''
        for r in range(merged_range.min_row, merged_range.max_row + 1):
            for c in range(merged_range.min_col, merged_range.max_col + 1):
                if r == merged_range.min_row and c == merged_range.min_col:
                    continue
                merge_map[(r, c)] = fill_val

    print(f'  [{fname}] 合併儲存格補值對照表：{len(merge_map)} 個格子')

    def cell_val(r, c):
        v = ws.cell(r, c).value
        if v is None or str(v).strip() == '':
            v = merge_map.get((r, c), '')
        if isinstance(v, float) and v == int(v):
            v = int(v)
        return str(v).strip() if v != '' and v is not None else ''

    max_col = ws.max_column
    raw_headers = [cell_val(1, c) for c in range(1, max_col + 1)]
    headers = [normalize_header(h) for h in raw_headers]

    def find_col(target):
        t = target.replace('(','').replace(')','')
        for i, h in enumerate(headers):
            if h == target:
                return i + 1
        for i, h in enumerate(headers):
            if t in h.replace('(','').replace(')',''):
                return i + 1
        return None

    col_id   = find_col('土方序號(ID)')
    col_ke   = find_col('客代')
    col_head = find_col('車牌號碼(車頭)')
    col_tail = find_col('車牌號碼(車尾)')
    col_st   = find_col('目前狀況')
    col_note = find_col('備註')

    print(f'  [{fname}] 欄位位置 → ID:{col_id}, 客代:{col_ke}, 車頭:{col_head}, 車尾:{col_tail}, 狀況:{col_st}, 備註:{col_note}')

    lookup = {}
    for r in range(2, ws.max_row + 1):
        key = cell_val(r, col_id) if col_id else ''
        if not key:
            continue
        lookup[key] = {
            '客代':         cell_val(r, col_ke)   if col_ke   else '',
            '車牌號碼（車頭）': cell_val(r, col_head) if col_head else '',
            '車牌號碼（車尾）': cell_val(r, col_tail) if col_tail else '',
            '目前狀況':       cell_val(r, col_st)   if col_st   else '',
            '備註':          cell_val(r, col_note) if col_note else '',
        }

    wb.close()
    print(f'  [{fname}] 載入 {len(lookup)} 筆')
    return lookup


# ── 讀取 Excel ───────────────────────────────────────────────────────────────

def load_excel_keys(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    headers = [str(h) if h is not None else '' for h in rows[0]]
    try:
        key_col = headers.index('車載裝置明碼')
    except ValueError:
        raise ValueError(f'找不到「車載裝置明碼」欄位，現有欄位：{headers}')
    keys = set()
    for row in rows[1:]:
        v = row[key_col]
        if v:
            keys.add(str(v).strip())
    return keys

def load_excel_rows(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    headers = [str(h) if h is not None else '' for h in rows[0]]
    data = []
    for row in rows[1:]:
        data.append(dict(zip(headers, [str(v).strip() if v is not None else '' for v in row])))
    return headers, data


# ── 主流程 ───────────────────────────────────────────────────────────────────

print('\n=== 步驟 1：讀取上次檔案（車載裝置明碼集合）')
prev_keys = load_excel_keys(PREV_FILE)
print(f'  上次筆數: {len(prev_keys)}')

print('=== 步驟 2：讀取本次檔案')
curr_headers, curr_rows = load_excel_rows(CURR_FILE)
print(f'  本次筆數: {len(curr_rows)}')

key_col = '車載裝置明碼'

print('=== 步驟 3：讀取 Google Sheets（XLSX，全欄合併格補值）')
lookup_a = load_sheets_xlsx(SHEETS_A)
lookup_b = load_sheets_xlsx(SHEETS_B)

print('=== 步驟 4：比對與欄位合併')
conflicts = []
both_found = []
new_cols = ['是否新增', '客代', '車牌號碼（車頭）', '車牌號碼（車尾）', '目前狀況', '備註', '是否要寄']
output_rows = []

cnt_new = 0
cnt_a_only = 0
cnt_b_only = 0
cnt_both = 0
cnt_none = 0

for row in curr_rows:
    code = row.get(key_col, '').strip()

    is_new = code not in prev_keys
    row['是否新增'] = '新增' if is_new else ''
    if is_new:
        cnt_new += 1

    rec_a = lookup_a.get(code)
    rec_b = lookup_b.get(code)

    if rec_a and not rec_b:
        merged = rec_a
        row['地區'] = '北竹'
        cnt_a_only += 1
    elif rec_b and not rec_a:
        merged = rec_b
        row['地區'] = '中南'
        cnt_b_only += 1
    elif rec_a and rec_b:
        cnt_both += 1
        both_found.append(code)
        merged = rec_a.copy()
        row['地區'] = '北竹'
        for field in rec_a:
            va = rec_a[field]
            vb = rec_b[field]
            if va != vb:
                conflicts.append({
                    '車載裝置明碼': code,
                    '欄位名稱': field,
                    'Sheets A 的值': va,
                    'Sheets B 的值': vb,
                })
    else:
        merged = {'客代': '', '車牌號碼（車頭）': '', '車牌號碼（車尾）': '', '目前狀況': '', '備註': ''}
        row['地區'] = ''
        cnt_none += 1

    for k, v in merged.items():
        row[k] = v

    row['是否要寄'] = '' if KEY_SENT in row.get('目前狀況', '') else '要寄'

    output_rows.append(row)

print(f'  新增筆數: {cnt_new}')
print(f'  僅在A: {cnt_a_only} | 僅在B: {cnt_b_only} | A+B: {cnt_both} | 都無: {cnt_none}')
print(f'  衝突筆數: {len(conflicts)}')

if both_found:
    print(f'\n⚠️  警告：以下 {len(both_found)} 筆車載裝置明碼同時出現在 Sheets A（北竹）與 Sheets B（中南）！')
    print('  → 已用 Sheets A 的值輸出，請人工確認這些明碼是否登錄錯誤：')
    for code in both_found:
        print(f'    - {code}')
    print()

print('=== 步驟 5：建立輸出 Excel')
wb_out = Workbook()

# ── 工作表一：本次新增筆數 ────────────────────────────────────────────────────
ws1 = wb_out.active
ws1.title = '本次新增筆數'

all_headers = curr_headers + new_cols
ws1.append(all_headers)

col_is_new  = all_headers.index('是否新增') + 1
col_curr_st = all_headers.index('目前狀況') + 1

for row in output_rows:
    values = [row.get(h, '') for h in all_headers]
    ws1.append(values)
    excel_row = ws1.max_row
    if row['是否新增'] == '新增':
        ws1.cell(row=excel_row, column=col_is_new).fill = FILL_RED
    if KEY_SENT in row.get('目前狀況', ''):
        ws1.cell(row=excel_row, column=col_curr_st).fill = FILL_GREEN

print(f'  工作表一：{ws1.max_row - 1} 筆')

# ── 工作表二：客代車牌 ────────────────────────────────────────────────────────
ws2 = wb_out.create_sheet('客代車牌')
ws2_headers = ['客代', '車牌號碼（車頭）', '車牌號碼（車尾）', '車載裝置明碼', '地區', 'OA301車牌', '安裝位置']
ws2.append(ws2_headers)

filtered = [r for r in output_rows if r.get('是否新增') == '新增' and r.get('是否要寄') == '要寄']
filtered.sort(key=lambda r: r.get('客代', ''))

prev_keydai = None
for row in filtered:
    kd = row.get('客代', '')
    display_kd = kd if kd != prev_keydai else ''
    ws2.append([display_kd, row.get('車牌號碼（車頭）', ''), row.get('車牌號碼（車尾）', ''), row.get(key_col, ''), row.get('地區', ''), row.get('車牌號碼', ''), row.get('安裝位置', '')])
    prev_keydai = kd

print(f'  工作表二：{len(filtered)} 筆（客代車牌）')

# ── 工作表三：衝突紀錄（條件觸發）────────────────────────────────────────────
if conflicts:
    ws3 = wb_out.create_sheet('衝突紀錄')
    ws3.append(['車載裝置明碼', '欄位名稱', 'Sheets A 的值', 'Sheets B 的值'])
    for c in conflicts:
        ws3.append([c['車載裝置明碼'], c['欄位名稱'], c['Sheets A 的值'], c['Sheets B 的值']])
    print(f'  工作表三：{len(conflicts)} 筆衝突')
else:
    print('  無衝突，不建立工作表三')

# ── 工作表四：A+B 異常（條件觸發）────────────────────────────────────────────
if both_found:
    ws4 = wb_out.create_sheet('AB異常')
    ws4.append(['車載裝置明碼', '說明'])
    for code in both_found:
        ws4.append([code, '同時出現於 Sheets A（北竹）與 Sheets B（中南），請人工確認'])
    print(f'  工作表四（AB異常）：{len(both_found)} 筆，請人工確認')
else:
    print('  無 A+B 異常，不建立工作表四')

wb_out.save(OUTPUT)
print(f'\n=== 完成：已儲存至 {OUTPUT}')
print(f'\n== 處理結果 ==')
print(f'本次總筆數: {len(output_rows)}')
print(f'新增筆數: {cnt_new}')
print(f'客代車牌輸出: {len(filtered)} 筆')
print(f'衝突筆數: {len(conflicts)}')
