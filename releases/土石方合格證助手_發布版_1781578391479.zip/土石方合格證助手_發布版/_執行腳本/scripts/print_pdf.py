"""
print_pdf.py
依照 合格證_已核可_YYYYMMDD_查詢.xlsx 客代車牌工作表的順序，
套用「土石方合格證」印表機設定後逐一列印 PDF。

印表機：RICOH MP C5503 PCL 6
設定：A6 / 手送台(bypasstray) / 縱向 / 彩色 / 單面
列印程式：SumatraPDF（取代 Adobe Acrobat，避免 /t 指令重複送印問題）

執行方式：
    python "_執行腳本\\scripts\\print_pdf.py"
"""

import sys
import time
import subprocess
import copy
from pathlib import Path
from datetime import date
import openpyxl
import win32print

sys.stdout.reconfigure(encoding='utf-8')

PROJECT_DIR   = Path(__file__).resolve().parents[2]
OUTPUT_FOLDER = PROJECT_DIR / "_已核可清單"
TODAY         = date.today().strftime("%Y%m%d")
PDF_DIR       = PROJECT_DIR / "_合格證檔案" / TODAY
SHEET_NAME    = "客代車牌"
PRINTER_NAME = "RICOH MP C5503 PCL 6"
SUMATRA      = r"C:\Users\EupUser\AppData\Local\SumatraPDF\SumatraPDF.exe"

# DEVMODE 常數
DMORIENT_PORTRAIT = 1
DMCOLOR_COLOR     = 2
DMDUP_SIMPLEX     = 1
DMPAPER_A6        = 70   # 105 x 148 mm
# RICOH bypasstray 對應 Windows DMBIN_MANUAL
DMBIN_BYPASS      = 4    # DMBIN_MANUAL / 手送台


# ── 讀取今天的 Excel ─────────────────────────────────────────────────────────

def find_today_excel() -> Path:
    pattern = f"合格證_已核可_{TODAY}_查詢.xlsx"
    files = [f for f in OUTPUT_FOLDER.glob(pattern) if not f.name.startswith("~$")]
    if not files:
        sys.exit(f"[錯誤] 找不到今天的 Excel：_產出/{pattern}")
    return files[0]


def get_print_order(excel_path: Path) -> list:
    wb = openpyxl.load_workbook(excel_path, read_only=True, data_only=True)
    if SHEET_NAME not in wb.sheetnames:
        sys.exit(f"[錯誤] 找不到工作表「{SHEET_NAME}」")
    ws = wb[SHEET_NAME]
    headers = [str(c.value).strip() if c.value else '' for c in next(ws.iter_rows(min_row=1, max_row=1))]

    def col(name):
        return headers.index(name) if name in headers else None

    i_head   = col("車牌號碼（車頭）")
    i_tail   = col("車牌號碼（車尾）")
    i_r_head = col("查詢結果（車頭）")
    i_r_tail = col("查詢結果（車尾）")

    order = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        head = str(row[i_head]).strip() if row[i_head] else ""
        tail = str(row[i_tail]).strip() if row[i_tail] else ""
        r_h  = str(row[i_r_head]).strip() if row[i_r_head] else ""
        r_t  = str(row[i_r_tail]).strip() if row[i_r_tail] else ""
        if "[OK]" in r_h and head and head != "nan":
            order.append((head, PDF_DIR / f"{head}.pdf"))
        elif "[OK]" in r_t and tail and tail != "nan":
            order.append((tail, PDF_DIR / f"{tail}.pdf"))
    wb.close()
    return order


# ── 套用印表機設定（per-user，不需 admin）────────────────────────────────────

def apply_printer_settings():
    """套用土石方合格證設定：A6 / 手送台 / 縱向 / 彩色 / 單面。回傳 (handle, orig_fields)。"""
    h = win32print.OpenPrinter(PRINTER_NAME)
    try:
        info = win32print.GetPrinter(h, 9)
        dm = info.get('pDevMode')
        if dm is None:
            info = win32print.GetPrinter(h, 2)
            dm = info['pDevMode']
    except Exception as e:
        win32print.ClosePrinter(h)
        raise RuntimeError(f"無法讀取印表機設定：{e}")

    # 記錄原始值（還原用）
    orig = {
        'PaperSize':     dm.PaperSize,
        'PaperLength':   dm.PaperLength,
        'PaperWidth':    dm.PaperWidth,
        'Orientation':   dm.Orientation,
        'Color':         dm.Color,
        'DefaultSource': dm.DefaultSource,
        'Duplex':        dm.Duplex,
    }

    # 套用土石方合格證設定
    dm.PaperSize     = DMPAPER_A6
    dm.PaperLength   = 1480   # 148.0 mm（DEVMODE 單位：0.1mm）
    dm.PaperWidth    = 1050   # 105.0 mm
    dm.Orientation   = DMORIENT_PORTRAIT
    dm.Color         = DMCOLOR_COLOR
    dm.DefaultSource = DMBIN_BYPASS
    dm.Duplex        = DMDUP_SIMPLEX

    win32print.SetPrinter(h, 9, {'pDevMode': dm}, 0)
    print(f"  [套用] A6 / 手送台 / 縱向 / 彩色 / 單面 → {PRINTER_NAME}")
    return h, dm, orig


def restore_printer_settings(h, dm, orig):
    for key, val in orig.items():
        try:
            setattr(dm, key, val)
        except Exception:
            pass
    try:
        win32print.SetPrinter(h, 9, {'pDevMode': dm}, 0)
        print("  [還原] 印表機設定已還原")
    except Exception as e:
        print(f"  [警告] 還原印表機設定失敗：{e}")
    win32print.ClosePrinter(h)


# ── 列印單一 PDF（Adobe Acrobat /t 靜默列印）────────────────────────────────

def print_pdf(pdf_path: Path) -> tuple[bool, str]:
    if not pdf_path.exists():
        return False, "找不到 PDF 檔案"
    try:
        subprocess.run(
            [SUMATRA, "-print-to", PRINTER_NAME, "-silent", str(pdf_path)],
            timeout=30,
            capture_output=True
        )
        return True, "已送出"
    except subprocess.TimeoutExpired:
        return False, "逾時（30s）"
    except Exception as e:
        return False, str(e)


# ── 環境檢查 ─────────────────────────────────────────────────────────────────

def check_env():
    errors = []

    if not Path(SUMATRA).exists():
        errors.append(f"找不到 SumatraPDF：{SUMATRA}\n  請確認 SumatraPDF 已安裝，或修改腳本中的 SUMATRA 路徑")

    try:
        printer_names = [p[2] for p in win32print.EnumPrinters(
            win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)]
        if PRINTER_NAME not in printer_names:
            errors.append(f"找不到印表機：{PRINTER_NAME}\n  請確認印表機已連線並安裝驅動")
    except Exception as e:
        errors.append(f"無法列舉印表機：{e}")

    pattern = f"合格證_已核可_{TODAY}_查詢.xlsx"
    excel_files = [f for f in OUTPUT_FOLDER.glob(pattern) if not f.name.startswith("~$")]
    if not excel_files:
        errors.append(f"找不到今天的 Excel：_已核可清單/{pattern}\n  請先執行步驟 3：query_gps_verify.py")
    elif any(OUTPUT_FOLDER.glob(f"~${pattern}")):
        errors.append(f"Excel 被 Excel 程式開著，請關閉後重新執行")

    if errors:
        print("\n[環境檢查失敗] 請修正以下問題後重新執行：\n")
        for i, e in enumerate(errors, 1):
            print(f"  {i}. {e}")
        sys.exit(1)

    print("[環境檢查] 通過\n")


# ── 主程式 ─────────────────────────────────────────────────────────────────

check_env()
excel_path = find_today_excel()
print(f"[來源] {excel_path.name}")
print(f"[PDF]  {PDF_DIR}")
print()

order = get_print_order(excel_path)
total = len(order)
print(f"[待列印] {total} 份")

if total == 0:
    sys.exit("[提示] 沒有找到任何 [OK] 已下載的 PDF")

print()
h, dm, orig = apply_printer_settings()
print()

ok = fail = 0
try:
    for i, (plate, pdf) in enumerate(order, 1):
        print(f"[{i:02d}/{total}] {plate} ... ", end="", flush=True)
        success, msg = print_pdf(pdf)
        if success:
            print(f"✓ {msg}")
            ok += 1
        else:
            print(f"✗ {msg}")
            fail += 1
        time.sleep(3)   # 每份間隔 3 秒，避免印表機佇列堵塞
finally:
    print()
    restore_printer_settings(h, dm, orig)

print(f"\n完成：成功 {ok} 份 / 失敗 {fail} 份")
