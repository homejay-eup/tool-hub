"""
update_sheets_after_shipping.py
寄送合格證後回寫 Google Sheets

執行方式：
    python "_執行腳本/scripts/update_sheets_after_shipping.py"

流程：
    1. 讀「客代車牌」工作表，取 EEW 碼清單
    2. 比對暫存 XLSX，判斷每筆 EEW 屬於北竹或中南 Sheets
    3. 顯示預覽（群組、列範圍、移動目標），等待確認
    4. 確認後：寫入目前狀況、清除底色、移動列、套用格式
"""

import sys
import os
import glob
import argparse
from pathlib import Path
from datetime import datetime

import openpyxl
from dotenv import load_dotenv
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

sys.stdout.reconfigure(encoding='utf-8')

# ── 路徑設定 ─────────────────────────────────────────────────────────────────
PROJECT_DIR = Path(__file__).resolve().parents[2]
TEMP        = PROJECT_DIR / '_暫存'
RESULT_DIR  = PROJECT_DIR / '_已核可清單'
SECRETS_DIR = PROJECT_DIR / '_secrets'

load_dotenv(PROJECT_DIR / '.env')

SHEET_TAB = '國土署-土石方'
SCOPES    = ['https://www.googleapis.com/auth/spreadsheets']

SPREADSHEET_IDS = {
    '北竹': '1QZi0k1I5ccuJqZuRK-4IctqSAqyOxtoP6wGnHqWI9VM',
    '中南': '1Z_gsxOdxR5GMlWnFiifD_yscInAOsmUV5zqlbgvGlWQ',
}

SHEETS_XLSX = {
    '北竹': TEMP / 'Sheets(北竹).xlsx',
    '中南': TEMP / 'Sheets(中南).xlsx',
}

# 欄位（0-based，對應 API 索引）
COL_KE   = 5   # 客代（第 6 欄）
COL_CUST = 6   # 客戶名稱（第 7 欄）
COL_EEW  = 10  # 土方序號(ID)（第 11 欄）
COL_ST   = 16  # 目前狀況（第 17 欄）
COL_AR   = 18  # A:R 共 18 欄

MERGE_COLS        = {COL_KE, COL_CUST}  # 以這兩欄的合併判斷群組
MARKER_FULL_TEXT  = '已送出 尚未完審區'   # 橘色標題列全文
MARKER_KWORD      = MARKER_FULL_TEXT    # 預覽輸出用（保留舊變數名稱）


# ── 環境檢查 ─────────────────────────────────────────────────────────────────
def check_env():
    errors = []
    if not (SECRETS_DIR / 'credentials.json').exists():
        errors.append(f'找不到 OAuth 憑證：{SECRETS_DIR / "credentials.json"}')
    if not list(RESULT_DIR.glob('*查詢.xlsx')):
        errors.append(f'找不到查詢結果 Excel（*查詢.xlsx）於：{RESULT_DIR}')
    if errors:
        print('\n[環境檢查失敗] 請修正以下問題後重新執行：\n')
        for i, e in enumerate(errors, 1):
            print(f'  {i}. {e}')
        sys.exit(1)
    print('[環境檢查] 通過\n')


# ── OAuth 認證 ────────────────────────────────────────────────────────────────
def get_credentials():
    cred_path  = SECRETS_DIR / 'credentials.json'
    token_path = SECRETS_DIR / 'token.json'
    creds = None
    if token_path.exists():
        creds = Credentials.from_authorized_user_file(str(token_path), SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(str(cred_path), SCOPES)
            creds = flow.run_local_server(port=0)
        token_path.write_text(creds.to_json())
    return creds


# ── 讀取「客代車牌」工作表 ────────────────────────────────────────────────────
def load_eew_list(excel_path):
    wb = openpyxl.load_workbook(excel_path, data_only=True)
    if '客代車牌' not in wb.sheetnames:
        raise ValueError(f'找不到「客代車牌」工作表，現有：{wb.sheetnames}')
    ws = wb['客代車牌']
    rows = list(ws.iter_rows(values_only=True))
    wb.close()

    headers = [str(h).strip() if h is not None else '' for h in rows[0]]
    eew_col = next((i for i, h in enumerate(headers) if '車載裝置明碼' in h), None)
    if eew_col is None:
        raise ValueError(f'找不到「車載裝置明碼」欄位，現有：{headers}')

    result = []
    for row in rows[1:]:
        eew = str(row[eew_col]).strip() if row[eew_col] is not None else ''
        if eew:
            result.append(eew)
    return result


# ── 從暫存 XLSX 判斷每個 EEW 屬於哪個 Sheets ────────────────────────────────
def map_eew_to_sheets(eew_set):
    mapping = {}
    for sname, xlsx_path in SHEETS_XLSX.items():
        if not xlsx_path.exists():
            print(f'  ⚠️  找不到 {xlsx_path.name}，跳過 {sname}')
            continue
        wb = openpyxl.load_workbook(xlsx_path, data_only=True)
        if SHEET_TAB not in wb.sheetnames:
            wb.close()
            continue
        ws = wb[SHEET_TAB]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if COL_EEW >= len(row) or row[COL_EEW] is None:
                continue
            eew = str(row[COL_EEW]).strip()
            if eew in eew_set and eew not in mapping:
                mapping[eew] = sname
        wb.close()
    return mapping


# ── 讀取 Sheets 資料（values + merges + sheet_id）─────────────────────────
def read_sheet(service, spreadsheet_id):
    values_result = service.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id,
        range=f"'{SHEET_TAB}'",
    ).execute()
    values = values_result.get('values', [])

    meta = service.spreadsheets().get(
        spreadsheetId=spreadsheet_id,
        fields='sheets(properties,merges)',
    ).execute()

    for sheet in meta.get('sheets', []):
        if sheet['properties']['title'] == SHEET_TAB:
            merges   = sheet.get('merges', [])
            sheet_id = sheet['properties']['sheetId']
            return values, merges, sheet_id

    raise ValueError(f'找不到工作表「{SHEET_TAB}」')


# ── 找 EEW 所在列（0-based row index）────────────────────────────────────────
def find_eew_rows(values, eew_set):
    result = {}
    for ri, row in enumerate(values[1:], start=1):
        if COL_EEW < len(row) and row[COL_EEW]:
            eew = str(row[COL_EEW]).strip()
            if eew in eew_set:
                result[eew] = ri
    return result


# ── 找合併群組（依 COL_KE / COL_CUST 的縱向合併，業務邏輯用）────────────────
def find_merge_group(row_idx, merges):
    group = {row_idx}
    for m in merges:
        if m['startColumnIndex'] in MERGE_COLS:
            if m['startRowIndex'] <= row_idx < m['endRowIndex']:
                group.update(range(m['startRowIndex'], m['endRowIndex']))
    return sorted(group)


# ── 擴充列集合，確保所有欄的縱向合併都完整包含（移動前必須呼叫）────────────
def expand_for_merges(row_set, merges):
    """
    避免「只包含部分合併儲存格的列」API 錯誤。
    對任何欄的縱向合併，只要 row_set 包含其中任一列，就把整個合併範圍納入。
    使用 fixed-point 迭代直到沒有新列加入為止。
    """
    expanded = set(row_set)
    changed = True
    while changed:
        changed = False
        for m in merges:
            if m['endRowIndex'] - m['startRowIndex'] <= 1:
                continue  # 橫向合併（單列），不影響行移動
            merge_rows = set(range(m['startRowIndex'], m['endRowIndex']))
            if expanded & merge_rows and not merge_rows.issubset(expanded):
                expanded.update(merge_rows)
                changed = True
    return sorted(expanded)


def update_merges_after_move(merges, start_idx, end_idx, dest):
    """
    移動列後同步更新合併儲存格的列位置，確保下一次 expand_for_merges 使用正確位置。
    支援向上（dest < start_idx）與向下（dest > end_idx）兩個方向。
    """
    rows_count = end_idx - start_idx
    updated = []
    for m in merges:
        ms = m['startRowIndex']
        me = m['endRowIndex']
        if dest <= start_idx:
            # 向上移動
            if me <= dest or ms >= end_idx:
                updated.append(m)                          # 範圍外：不受影響
            elif ms >= start_idx and me <= end_idx:
                updated.append({**m,                       # 移動列內：跟著移到 dest
                    'startRowIndex': dest + (ms - start_idx),
                    'endRowIndex':   dest + (me - start_idx)})
            elif dest <= ms and me <= start_idx:
                updated.append({**m,                       # [dest, start_idx) 內：向下位移
                    'startRowIndex': ms + rows_count,
                    'endRowIndex':   me + rows_count})
            else:
                updated.append(m)                          # 跨邊界（不應發生）：保留
        else:
            # 向下移動（dest > end_idx）
            actual_dest = dest - rows_count
            if ms >= end_idx and me <= dest:
                updated.append({**m,                       # [end_idx, dest) 內：向上位移
                    'startRowIndex': ms - rows_count,
                    'endRowIndex':   me - rows_count})
            elif ms >= start_idx and me <= end_idx:
                updated.append({**m,                       # 移動列內：跟著移到 actual_dest
                    'startRowIndex': actual_dest + (ms - start_idx),
                    'endRowIndex':   actual_dest + (me - start_idx)})
            else:
                updated.append(m)                          # 範圍外：不受影響
    return updated


# ── 讀取指定列的背景色（橘色驗證用）────────────────────────────────────────
def get_row_background(service, sp_id, row_idx):
    """讀取指定列（0-based）第一個有背景色的格子，回傳 {red, green, blue} 或 None"""
    row_num = row_idx + 1  # 1-based
    try:
        result = service.spreadsheets().get(
            spreadsheetId=sp_id,
            ranges=[f"'{SHEET_TAB}'!A{row_num}:R{row_num}"],
            fields='sheets.data.rowData.values.userEnteredFormat.backgroundColor',
            includeGridData=True,
        ).execute()
        data = result.get('sheets', [{}])[0].get('data', [{}])[0]
        for cell in data.get('rowData', [{}])[0].get('values', []):
            bg = cell.get('userEnteredFormat', {}).get('backgroundColor', {})
            # 只回傳非白色（白色預設值 red=green=blue=1）
            if bg and not (bg.get('red', 1) == 1 and bg.get('green', 1) == 1 and bg.get('blue', 1) == 1):
                return bg
    except Exception:
        pass
    return None


def is_orange(bg):
    """判斷背景色是否為橘色（紅高、綠中、藍低）"""
    if not bg:
        return False
    r = bg.get('red',   1.0)
    g = bg.get('green', 1.0)
    b = bg.get('blue',  1.0)
    return r > 0.7 and 0.25 < g < 0.85 and b < 0.35


# ── 找「已送出 尚未完審區」標題列（0-based row index）────────────────────────
def find_marker_row(values, service=None, sp_id=None):
    """
    定位策略（b+c 雙重驗證）：
      1. 全文比對 MARKER_FULL_TEXT
      2. 若找到多列，再用橘色背景過濾
      3. 若全文只找到 1 列，直接採用
      4. fallback：僅用「尚未完審區」比對
    """
    candidates = []
    for ri, row in enumerate(values):
        if any(MARKER_FULL_TEXT in str(cell) for cell in row if cell):
            candidates.append(ri)

    if not candidates:
        # fallback：放寬為部分比對
        for ri, row in enumerate(values):
            if any('尚未完審區' in str(cell) for cell in row if cell):
                candidates.append(ri)

    if not candidates:
        return None

    if len(candidates) == 1:
        return candidates[0]

    # 多個候選：用橘色背景選出正確的標題列
    if service and sp_id:
        orange_rows = [ri for ri in candidates if is_orange(get_row_background(service, sp_id, ri))]
        if len(orange_rows) == 1:
            return orange_rows[0]
        if len(orange_rows) > 1:
            return orange_rows[0]  # 取第一個橘色列

    # 最後 fallback：取最後一個候選（標題列通常在較下方）
    return candidates[-1]


# ── 取格子值（補空字串）──────────────────────────────────────────────────────
def cell_val(row, col):
    return str(row[col]).strip() if col < len(row) and row[col] is not None else ''


# ── 主程式 ───────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description='寄送合格證後回寫 Google Sheets')
    parser.add_argument('--date', help='寄送日期（格式：M/D，例如 6/10）')
    parser.add_argument('--yes', action='store_true', help='跳過確認直接執行')
    parser.add_argument('--preview-only', action='store_true', help='只顯示預覽，不執行')
    args = parser.parse_args()

    check_env()

    if args.date:
        ship_date = args.date.strip()
        print(f'寄送日期（命令列）：{ship_date}')
    else:
        ship_date = input('請輸入寄送日期（格式：M/D，例如 6/10）：').strip()
    if not ship_date:
        print('未輸入日期，結束')
        sys.exit(0)

    # 自動找最新查詢 Excel
    excel_files = sorted(
        (p for p in RESULT_DIR.glob('*查詢.xlsx') if not p.name.startswith('~$')),
        key=lambda p: p.stat().st_mtime, reverse=True
    )
    if not excel_files:
        print(f'找不到 *查詢.xlsx 於 {RESULT_DIR}')
        sys.exit(1)
    excel_path = excel_files[0]
    print(f'使用 Excel：{excel_path.name}')

    eew_list = load_eew_list(excel_path)
    eew_set  = set(eew_list)
    print(f'本次寄送 EEW：{len(eew_list)} 筆\n')

    # 判斷每個 EEW 屬哪個 Sheets
    eew_map = map_eew_to_sheets(eew_set)

    not_found = [e for e in eew_list if e not in eew_map]
    if not_found:
        print(f'⚠️  以下 EEW 在北竹/中南 Sheets 均未找到（共 {len(not_found)} 筆）：')
        for e in not_found:
            print(f'   {e}')
        print()

    sheets_eews = {}
    for eew, sname in eew_map.items():
        sheets_eews.setdefault(sname, set()).add(eew)

    if not sheets_eews:
        print('沒有可處理的 EEW，結束')
        sys.exit(0)

    # OAuth
    print('正在取得 Google Sheets 授權...')
    creds   = get_credentials()
    service = build('sheets', 'v4', credentials=creds)
    print('授權成功\n')

    # ── 分析各 Sheets，建立操作計畫 ────────────────────────────────────────
    plans = {}

    for sname, eews in sheets_eews.items():
        sp_id = SPREADSHEET_IDS[sname]
        print(f'=== 讀取 {sname} Sheets ===')
        values, merges, sheet_id = read_sheet(service, sp_id)

        eew_rows = find_eew_rows(values, eews)
        if not eew_rows:
            print(f'  ⚠️  未在 {sname} Sheets 中找到 EEW，跳過')
            continue

        marker_row = find_marker_row(values, service, sp_id)
        if marker_row is None:
            print(f'  ⚠️  找不到「{MARKER_KWORD}」標題列，跳過 {sname}')
            continue

        print(f'  EEW 找到：{len(eew_rows)} 筆')
        print(f'  「{MARKER_KWORD}」位於第 {marker_row + 1} 列')

        # 識別合併群組
        seen = set()
        groups = []
        for eew, ri in sorted(eew_rows.items(), key=lambda x: x[1]):
            if ri in seen:
                continue
            group_rows = find_merge_group(ri, merges)
            seen.update(group_rows)

            group_ke   = cell_val(values[group_rows[0]], COL_KE)
            group_cust = cell_val(values[group_rows[0]], COL_CUST)
            group_eews = [e for e, r in eew_rows.items() if r in set(group_rows)]

            groups.append({
                'rows':      group_rows,
                'ke':        group_ke,
                'cust':      group_cust,
                'eews':      group_eews,
            })

        plans[sname] = {
            'spreadsheet_id': sp_id,
            'sheet_id':       sheet_id,
            'groups':         groups,
            'marker_row':     marker_row,
            'merges':         merges,
        }

    if not plans:
        print('沒有可執行的計畫，結束')
        sys.exit(0)

    # ── 顯示預覽 ─────────────────────────────────────────────────────────────
    print('\n' + '=' * 60)
    print('預覽 — 確認後才會執行寫入')
    print('=' * 60)

    total_eews = 0
    for sname, plan in plans.items():
        print(f'\n【{sname} Sheets】')
        print(f'  「{MARKER_KWORD}」位於第 {plan["marker_row"] + 1} 列')
        for i, g in enumerate(plan['groups'], 1):
            row_range = f'第 {g["rows"][0] + 1}–{g["rows"][-1] + 1} 列'
            extra = len(g['rows']) - len(g['eews'])
            label = g['ke'] or g['cust'] or '(空)'
            print(f'\n  群組 {i}：{label}')
            print(f'    列範圍：{row_range}（共 {len(g["rows"])} 列）')
            print(f'    本次寄送 EEW：{", ".join(g["eews"])}')
            if extra > 0:
                print(f'    連帶移動（不寫目前狀況）：{extra} 列')
            print(f'    → 移動至第 {plan["marker_row"] + 1} 列上方')
            total_eews += len(g['eews'])

    print(f'\n寄送日期：{ship_date}')
    print(f'寫入格式：「{ship_date} 寄出合格證至客端」（前置於原內容）')
    print(f'共計：{total_eews} 筆 EEW 寫入目前狀況\n')

    if args.preview_only:
        print('（--preview-only 模式：不執行寫入）')
        sys.exit(0)

    if args.yes:
        print('（--yes 模式：自動確認）')
    else:
        confirm = input('確認執行？(y/n)：').strip().lower()
        if confirm != 'y':
            print('已取消，未執行任何寫入')
            sys.exit(0)

    # ── 執行 ─────────────────────────────────────────────────────────────────
    success = 0
    fail    = 0

    for sname, plan in plans.items():
        sp_id    = plan['spreadsheet_id']
        sheet_id = plan['sheet_id']
        groups   = plan['groups']
        marker   = plan['marker_row']

        print(f'\n=== 執行 {sname} Sheets ===')

        # 移動群組（從底部往上）
        # 說明：
        #   - 群組在 marker 上方（row < marker）→ 向下移，marker 不動
        #   - 群組在 marker 下方（row >= marker）→ 向上移，每移一批 marker 往下偏移 rows_count，
        #     同時更新介於 old_marker～current_group 之間其餘群組的行號
        plan_merges   = plan['merges']
        sorted_groups = sorted(groups, key=lambda g: g['rows'][0], reverse=True)
        failed_eews   = set()   # 移動失敗的 EEW，格式更新時排除
        succeeded_eews = set()  # 移動成功的 EEW

        for i, g in enumerate(sorted_groups):
            # expand_for_merges：確保移動範圍包含所有欄的縱向合併，避免局部合併 API 錯誤
            full_rows  = expand_for_merges(set(g['rows']), plan_merges)
            start_idx  = full_rows[0]
            end_idx    = full_rows[-1] + 1  # exclusive
            rows_count = end_idx - start_idx
            dest = marker  # 記錄本次移動目標，供事後更新合併表用
            try:
                service.spreadsheets().batchUpdate(
                    spreadsheetId=sp_id,
                    body={'requests': [{
                        'moveDimension': {
                            'source': {
                                'sheetId':    sheet_id,
                                'dimension':  'ROWS',
                                'startIndex': start_idx,
                                'endIndex':   end_idx,
                            },
                            'destinationIndex': marker,
                        }
                    }]}
                ).execute()
                ke_label = g['ke'] or g['cust'] or '(空)'
                extra = rows_count - len(g['rows'])
                extra_str = f'（含連帶 {extra} 列）' if extra else ''
                print(f'  ✅ 移動（{ke_label}）：第 {start_idx + 1}–{end_idx} 列{extra_str} → 第 {marker + 1} 列上方')
                succeeded_eews.update(g['eews'])

                # 同步更新合併儲存格位置，確保下一次 expand_for_merges 使用正確位置
                plan_merges = update_merges_after_move(plan_merges, start_idx, end_idx, dest)

                # ── 從下方往上移：更新 marker 及後續群組行號 ──────────────
                if start_idx >= marker:
                    old_marker = marker
                    marker += rows_count
                    for j in range(i + 1, len(sorted_groups)):
                        other = sorted_groups[j]
                        if old_marker <= other['rows'][0] < start_idx:
                            sorted_groups[j] = dict(other, rows=[r + rows_count for r in other['rows']])
                # 從上方往下移：marker 不動，不需調整

            except Exception as e:
                ke_label = g['ke'] or g['cust'] or '(空)'
                print(f'  ❌ 移動失敗（{ke_label}，EEW: {", ".join(g["eews"])}）：{e}')
                fail += len(g['eews'])
                failed_eews.update(g['eews'])

        if not succeeded_eews:
            print('  所有群組移動失敗，略過格式更新')
            continue

        if failed_eews:
            print(f'  ⚠️  {len(failed_eews)} 筆 EEW 移動失敗，其餘 {len(succeeded_eews)} 筆繼續更新格式')

        # 重新讀取確認移動後位置（只處理成功移動的 EEW）
        print('  重新讀取 Sheets...')
        values2, merges2, _ = read_sheet(service, sp_id)
        eew_rows2 = find_eew_rows(values2, succeeded_eews)

        if not eew_rows2:
            print('  ⚠️  移動後找不到 EEW，略過格式更新')
            fail += len(all_eews)
            continue

        # 找所有移動後群組的列範圍（含連帶列）
        seen2  = set()
        all_group_rows = set()
        for eew, ri in eew_rows2.items():
            if ri in seen2:
                continue
            group_rows2 = find_merge_group(ri, merges2)
            seen2.update(group_rows2)
            all_group_rows.update(group_rows2)

        # 建立批次請求
        requests = []

        # 1. 寫入目前狀況（只寫本次寄送 EEW 的列）
        for eew, ri in eew_rows2.items():
            old_st    = cell_val(values2[ri], COL_ST)
            new_st    = f'{ship_date} 寄出合格證至客端'
            if old_st:
                new_st = new_st + '\n' + old_st
            requests.append({
                'updateCells': {
                    'range': {
                        'sheetId':          sheet_id,
                        'startRowIndex':    ri,
                        'endRowIndex':      ri + 1,
                        'startColumnIndex': COL_ST,
                        'endColumnIndex':   COL_ST + 1,
                    },
                    'rows': [{'values': [{
                        'userEnteredValue': {'stringValue': new_st},
                        'userEnteredFormat': {
                            'textFormat': {
                                'fontFamily': 'Calibri',
                                'fontSize': 10,
                                'bold': True,
                            },
                            'wrapStrategy': 'WRAP',
                        },
                    }]}],
                    'fields': 'userEnteredValue,userEnteredFormat.textFormat,userEnteredFormat.wrapStrategy',
                }
            })

        # 2. 清除 A:R 底色（所有群組列）+ 套用 Calibri 10pt 粗體
        for ri in sorted(all_group_rows):
            # 清除底色
            requests.append({
                'repeatCell': {
                    'range': {
                        'sheetId':          sheet_id,
                        'startRowIndex':    ri,
                        'endRowIndex':      ri + 1,
                        'startColumnIndex': 0,
                        'endColumnIndex':   COL_AR,
                    },
                    'cell': {
                        'userEnteredFormat': {
                            'backgroundColor': {'red': 1, 'green': 1, 'blue': 1},
                            'textFormat': {
                                'fontFamily': 'Calibri',
                                'fontSize': 10,
                                'bold': True,
                            },
                        }
                    },
                    'fields': 'userEnteredFormat.backgroundColor,userEnteredFormat.textFormat',
                }
            })

        # 執行批次更新
        try:
            service.spreadsheets().batchUpdate(
                spreadsheetId=sp_id,
                body={'requests': requests}
            ).execute()
            print(f'  ✅ 格式更新完成（{len(eew_rows2)} 筆 EEW，{len(all_group_rows)} 列）')
            success += len(eew_rows2)
        except Exception as e:
            print(f'  ❌ 格式更新失敗：{e}')
            fail += len(all_eews)

    # ── 回報 ─────────────────────────────────────────────────────────────────
    print('\n' + '=' * 60)
    print('## 處理結果')
    print(f'- 成功：{success} 筆 EEW')
    print(f'- 失敗：{fail} 筆 EEW')
    print('=' * 60)


if __name__ == '__main__':
    main()
