"""
download_sheets.py
用 Google Sheets API 下載北竹、中南工作表，存為 XLSX 至 _暫存/
（不需要 Drive API，只需 Sheets API）
"""
import sys
import io
from pathlib import Path
from openpyxl import Workbook

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

PROJECT_DIR = Path(__file__).resolve().parents[2]
SECRETS_DIR = PROJECT_DIR / '_secrets'
TEMP_DIR    = PROJECT_DIR / '_暫存'

SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

SHEET_TAB = '國土署-土石方'

SPREADSHEET_IDS = {
    '北竹': '1QZi0k1I5ccuJqZuRK-4IctqSAqyOxtoP6wGnHqWI9VM',
    '中南': '1Z_gsxOdxR5GMlWnFiifD_yscInAOsmUV5zqlbgvGlWQ',
}


def get_credentials():
    cred_path  = SECRETS_DIR / 'credentials.json'
    token_path = SECRETS_DIR / 'token.json'
    creds = None

    if token_path.exists():
        creds = Credentials.from_authorized_user_file(str(token_path), SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except Exception:
                creds = None
        if not creds or not creds.valid:
            flow = InstalledAppFlow.from_client_secrets_file(str(cred_path), SCOPES)
            creds = flow.run_local_server(port=0)
        token_path.write_text(creds.to_json())

    return creds


def _download_one(service, spreadsheet_id, dest_path, name):
    print(f'  正在下載 Sheets({name})...')

    # 取得儲存格值
    values_result = service.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id,
        range=f"'{SHEET_TAB}'"
    ).execute()
    values = values_result.get('values', [])

    # 取得合併儲存格資訊
    meta = service.spreadsheets().get(
        spreadsheetId=spreadsheet_id,
        fields='sheets(properties,merges)'
    ).execute()
    merges = []
    for sheet in meta.get('sheets', []):
        if sheet['properties']['title'] == SHEET_TAB:
            merges = sheet.get('merges', [])
            break

    # 將合併儲存格的值填入每個子格（讓 process.py 可以正確讀到）
    for m in merges:
        r0 = m['startRowIndex']
        c0 = m['startColumnIndex']
        r1 = m['endRowIndex']       # exclusive
        c1 = m['endColumnIndex']    # exclusive
        val = values[r0][c0] if r0 < len(values) and c0 < len(values[r0]) else ''
        for r in range(r0, r1):
            for c in range(c0, c1):
                if r == r0 and c == c0:
                    continue
                while len(values) <= r:
                    values.append([])
                while len(values[r]) <= c:
                    values[r].append('')
                if not values[r][c]:
                    values[r][c] = val

    # 寫入 xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET_TAB
    for row in values:
        ws.append(row)
    wb.save(str(dest_path))

    size_kb = dest_path.stat().st_size // 1024
    print(f'  Sheets({name}) 下載完成（{size_kb} KB）')


def download_all_sheets():
    TEMP_DIR.mkdir(exist_ok=True)
    print('[下載 Sheets] 取得 Google 授權...')
    creds = get_credentials()
    service = build('sheets', 'v4', credentials=creds)

    for name, sid in SPREADSHEET_IDS.items():
        dest = TEMP_DIR / f'Sheets({name}).xlsx'
        _download_one(service, sid, dest, name)

    print('[下載 Sheets] 完成\n')


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    download_all_sheets()
