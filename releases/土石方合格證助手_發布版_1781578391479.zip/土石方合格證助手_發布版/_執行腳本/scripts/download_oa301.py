"""
download_oa301.py
自動登入土石方審驗系統，下載 OA301 已核可清單 CSV，轉存為 XLSX

執行方式：
    python _執行腳本/scripts/download_oa301.py

輸出：
    _國土署匯出檔/合格證_已核可_匯出檔_MMDD_筆數.xlsx
    舊檔自動移入 _國土署匯出檔/archived/
"""

import asyncio
import re
import sys
import os
from pathlib import Path
from datetime import datetime

import pandas as pd
from dotenv import load_dotenv
from playwright.async_api import async_playwright

# ── 設定 ──────────────────────────────────────────────────────────────
PROJECT_DIR = Path(__file__).resolve().parents[2]
load_dotenv(PROJECT_DIR / ".env")
TODAY_MMDD  = datetime.now().strftime("%m%d")
OA301_URL   = "https://gps-verify.nlma.gov.tw/APARS/OA301"
LOGIN_URL   = "https://www.cp.gov.tw/portal/Clogin.aspx?ReturnUrl=https%3a%2f%2fcloudbm.nlma.gov.tw%2fbccs%2fegovrtn&ver=Simple&Level=1"
OUTPUT_DIR  = PROJECT_DIR / "_國土署匯出檔"
ARCHIVE_DIR = OUTPUT_DIR / "archived"
TEMP_CSV    = PROJECT_DIR / "_暫存" / "oa301_temp.csv"


# ── 環境檢查 ──────────────────────────────────────────────────────────
def check_env():
    errors = []

    env_path = PROJECT_DIR / ".env"
    if not env_path.exists():
        errors.append(f".env 檔案不存在：{env_path}\n  請建立 .env 並設定 GPS_USERNAME / GPS_PASSWORD")
    else:
        from dotenv import dotenv_values
        cfg = dotenv_values(env_path)
        if not cfg.get("GPS_USERNAME"):
            errors.append(".env 缺少 GPS_USERNAME")
        if not cfg.get("GPS_PASSWORD"):
            errors.append(".env 缺少 GPS_PASSWORD")

    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            chromium_path = Path(pw.chromium.executable_path)
        if not chromium_path.exists():
            errors.append("Playwright Chromium 未下載\n  請執行：playwright install chromium")
    except Exception:
        errors.append("Playwright Chromium 未下載或無法啟動\n  請執行：playwright install chromium")

    if errors:
        print("\n[環境檢查失敗] 請修正以下問題後重新執行：\n")
        for i, e in enumerate(errors, 1):
            print(f"  {i}. {e}")
        sys.exit(1)

    print("[環境檢查] 通過\n")


# ── 登入（同 query_gps_verify.py）─────────────────────────────────────
async def login(page):
    """透過「我的E政府帳號登入」全自動登入，回傳 GPS 系統的新分頁"""
    username = os.getenv("GPS_USERNAME")
    password = os.getenv("GPS_PASSWORD")
    if not username or not password:
        sys.exit("[錯誤] 找不到帳號密碼，請確認 .env 含 GPS_USERNAME / GPS_PASSWORD")

    print(f"[登入] 帳號：{username} ...")
    await page.goto(LOGIN_URL, wait_until="networkidle", timeout=30000)
    await page.locator("input[placeholder='帳號']").fill(username)
    pwd_input = page.locator("input[placeholder='密碼']")
    await pwd_input.fill(password)
    await pwd_input.press("Enter")
    await page.wait_for_load_state("networkidle", timeout=20000)

    if "cp.gov.tw" in page.url:
        sys.exit("[錯誤] 登入失敗，請確認帳號密碼")

    print("[登入] 成功，進入土石方審驗系統...")
    gps_link = page.locator("text=全國營建剩餘土石方即時追蹤流向管控審驗系統")
    await gps_link.wait_for(timeout=15000)
    async with page.context.expect_page() as new_page_info:
        await gps_link.click()
    gps_page = await new_page_info.value
    await gps_page.wait_for_load_state("networkidle", timeout=30000)
    return gps_page


# ── 取結果總筆數 ──────────────────────────────────────────────────────
async def get_total_count(page) -> int:
    """從分頁列讀取「正在顯示記錄 X - Y 的 Z」，回傳 Z"""
    try:
        await page.wait_for_selector("div.statusArea", timeout=15000)
        await page.wait_for_timeout(800)
        full_text = await page.inner_text("body")
        matches = re.findall(r'正在顯示記錄\s*\d+\s*-\s*\d+\s*的\s*(\d+)', full_text)
        return int(matches[-1]) if matches else 0
    except Exception:
        return 0


# ── 主程式 ──────────────────────────────────────────────────────────
async def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    TEMP_CSV.parent.mkdir(parents=True, exist_ok=True)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context(accept_downloads=True)
        page    = await context.new_page()

        # 登入，取得 GPS 系統分頁
        page = await login(page)

        # 導向 OA301
        print("[導航] 進入 OA301 資料操作審驗申請...")
        await page.goto(OA301_URL, wait_until="networkidle", timeout=30000)

        # 申請狀態選「已核可」(value="4")
        await page.select_option("select#status", "4")
        print("[設定] 申請狀態 = 已核可")

        # 按查詢
        await page.locator("div.btnBox button").first.click()
        await page.wait_for_selector("div.statusArea", timeout=60000)

        # 取總筆數
        total = await get_total_count(page)
        print(f"[查詢] 查詢成功，共 {total} 筆")
        if total == 0:
            sys.exit("[錯誤] 查到 0 筆，請確認條件是否正確")

        # 下載 CSV
        print("[下載] 下載 CSV 中...")
        async with page.expect_download(timeout=60000) as dl_info:
            await page.locator("button[onclick='queryCsv();']").click()
        dl = await dl_info.value
        await dl.save_as(TEMP_CSV)
        print(f"[下載] 完成：{TEMP_CSV.name}")

        await browser.close()

    # ── CSV 轉 XLSX ──────────────────────────────────────────────────
    print("[轉換] CSV → XLSX ...")
    try:
        df = pd.read_csv(TEMP_CSV, encoding="utf-8-sig")
    except UnicodeDecodeError:
        df = pd.read_csv(TEMP_CSV, encoding="cp950")

    # 舊檔移入 archived/
    old_files = list(OUTPUT_DIR.glob("合格證_已核可_匯出檔_*.xlsx"))
    for f in old_files:
        dest = ARCHIVE_DIR / f.name
        f.replace(dest)
        print(f"[封存] {f.name} → archived/")

    # 存新 XLSX
    out_name = f"合格證_已核可_匯出檔_{TODAY_MMDD}_{total}.xlsx"
    out_path = OUTPUT_DIR / out_name
    df.to_excel(out_path, index=False)

    print(f"""
══════════════════════════════════════
  下載結果
══════════════════════════════════════
  輸出檔案：{out_name}
  總筆數：  {total} 筆
  欄位數：  {len(df.columns)} 欄
  存放位置：{OUTPUT_DIR}
══════════════════════════════════════
""")


if __name__ == "__main__":
    check_env()
    asyncio.run(main())
