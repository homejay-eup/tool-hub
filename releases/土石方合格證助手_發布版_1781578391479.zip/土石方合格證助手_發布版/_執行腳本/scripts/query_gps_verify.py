"""
query_gps_verify.py
自動查詢 https://gps-verify.nlma.gov.tw/APARS/OA401
並下載審驗合格車輛產證 PDF

執行方式：
    python _執行腳本/scripts/query_gps_verify.py
"""

import asyncio
import re
import sys
import os
from pathlib import Path
from datetime import datetime

import pandas as pd
import openpyxl
from dotenv import load_dotenv
from playwright.async_api import async_playwright

# ── 設定 ──────────────────────────────────────────────────────────────
PROJECT_DIR  = Path(__file__).resolve().parents[2]
OUTPUT_FOLDER = PROJECT_DIR / "_已核可清單"
load_dotenv(PROJECT_DIR / ".env")
TODAY       = datetime.now().strftime("%Y%m%d")
URL         = "https://gps-verify.nlma.gov.tw/APARS/OA401"
OUTPUT_DIR  = PROJECT_DIR / "_合格證檔案" / TODAY
SHEET_NAME  = "客代車牌"


# ── 環境檢查 ──────────────────────────────────────────────────────────
def check_env():
    errors = []

    env_path = PROJECT_DIR / ".env"
    if not env_path.exists():
        errors.append(f".env 檔案不存在：{env_path}\n  請建立 .env 並設定 GPS_USERNAME / GPS_PASSWORD")
    else:
        from dotenv import dotenv_values
        cfg = dotenv_values(env_path)
        if not cfg.get("GPS_USERNAME"):
            errors.append(".env 缺少 GPS_USERNAME")
        if not cfg.get("GPS_PASSWORD"):
            errors.append(".env 缺少 GPS_PASSWORD")

    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            chromium_path = Path(pw.chromium.executable_path)
        if not chromium_path.exists():
            errors.append("Playwright Chromium 未下載\n  請執行：playwright install chromium")
    except Exception:
        errors.append("Playwright Chromium 未下載或無法啟動\n  請執行：playwright install chromium")

    pattern = f"合格證_已核可_{TODAY}_查詢.xlsx"
    excel_files = [f for f in OUTPUT_FOLDER.glob(pattern) if not f.name.startswith("~$")]
    if not excel_files:
        errors.append(f"找不到今天的 Excel：_已核可清單/{pattern}\n  請先執行步驟 2：process.py")

    if errors:
        print("\n[環境檢查失敗] 請修正以下問題後重新執行：\n")
        for i, e in enumerate(errors, 1):
            print(f"  {i}. {e}")
        sys.exit(1)

    print("[環境檢查] 通過\n")


# ── 登入 ──────────────────────────────────────────────────────────────
# 我的E政府帳號登入頁（直接跳到帳密輸入，不需驗證碼）
LOGIN_URL = "https://www.cp.gov.tw/portal/Clogin.aspx?ReturnUrl=https%3a%2f%2fcloudbm.nlma.gov.tw%2fbccs%2fegovrtn&ver=Simple&Level=1"

async def login(page):
    """
    透過「我的E政府帳號登入」頁全自動登入（無驗證碼）
    登入成功後導向查詢頁 OA401
    """
    username = os.getenv("GPS_USERNAME")
    password = os.getenv("GPS_PASSWORD")
    if not username or not password:
        sys.exit("[錯誤] 找不到帳號密碼，請確認 .env 檔案存在且包含 GPS_USERNAME / GPS_PASSWORD")

    print(f"[登入] 帳號：{username} ...")
    await page.goto(LOGIN_URL, wait_until="networkidle", timeout=30000)

    # 填入帳號、密碼，按 Enter 提交
    await page.locator("input[placeholder='帳號']").fill(username)
    pwd_input = page.locator("input[placeholder='密碼']")
    await pwd_input.fill(password)
    await pwd_input.press("Enter")
    await page.wait_for_load_state("networkidle", timeout=20000)

    # 確認登入成功（應已離開 cp.gov.tw）
    if "cp.gov.tw" in page.url:
        sys.exit("[錯誤] 登入失敗，請確認帳號密碼是否正確")

    print("[登入] 成功，進入土石方審驗系統...")

    # 步驟 1：點「全國營建剩餘土石方即時追蹤流向管控審驗系統」連結
    gps_link = page.locator("text=全國營建剩餘土石方即時追蹤流向管控審驗系統")
    await gps_link.wait_for(timeout=15000)
    async with page.context.expect_page() as new_page_info:
        await gps_link.click()
    gps_page = await new_page_info.value
    await gps_page.wait_for_load_state("networkidle", timeout=30000)

    # 步驟 2+3：直接導向 OA401（無需逐層點選選單）
    await gps_page.goto(URL, wait_until="networkidle", timeout=30000)
    print("[導航] 已進入 OA401 查詢頁")
    return gps_page  # 回傳新分頁給主程式使用


# ── 找今天的 Excel ─────────────────────────────────────────────────────
def find_today_excel() -> Path:
    pattern = f"合格證_已核可_{TODAY}_查詢.xlsx"
    files = [f for f in OUTPUT_FOLDER.glob(pattern) if not f.name.startswith("~$")]
    if not files:
        sys.exit(f"[錯誤] 找不到今天的檔案：_產出/{pattern}")
    return files[0]


# ── 讀取結果筆數 ──────────────────────────────────────────────────────
async def get_result_count(page) -> int:
    """從分頁列讀取「正在顯示記錄 X - Y 的 Z」，回傳 Z"""
    try:
        # 等 statusArea 出現（查詢成功 / 查詢成功，無資料）
        await page.wait_for_selector("div.statusArea", timeout=10000)
        # 取整頁文字，找「的 N」模式（分頁列右下角）
        full_text = await page.inner_text("body")
        matches = re.findall(r'正在顯示記錄\s*\d+\s*-\s*\d+\s*的\s*(\d+)', full_text)
        return int(matches[-1]) if matches else 0
    except Exception:
        return 0


# ── 下載 PDF ──────────────────────────────────────────────────────────
async def download_pdf(page, plate_raw: str, output_dir: Path) -> str:
    """
    點擊下載按鈕，儲存 PDF。
    優先嘗試 popup（blob URL），若失敗改用 expect_download。
    回傳結果描述。
    """
    out_path = output_dir / f"{plate_raw}.pdf"

    # 方法 1：blob URL 開新分頁
    try:
        async with page.context.expect_page(timeout=10000) as popup_info:
            # GijGo grid 裡的下載按鈕
            await page.locator("div[data-role='wrapper'] button").first.click()
        popup = await popup_info.value
        await popup.wait_for_load_state("domcontentloaded", timeout=15000)

        pdf_bytes = await popup.evaluate("""
            async () => {
                const res = await fetch(document.URL);
                const buf = await res.arrayBuffer();
                return Array.from(new Uint8Array(buf));
            }
        """)
        await popup.close()

        with open(out_path, "wb") as f:
            f.write(bytes(pdf_bytes))
        return "[OK] 已下載"

    except Exception as e1:
        # 方法 2：直接觸發下載（非 blob）
        try:
            async with page.expect_download(timeout=15000) as dl_info:
                await page.locator("text=下載").first.click()
            dl = await dl_info.value
            await dl.save_as(out_path)
            return "[OK] 已下載"
        except Exception as e2:
            return f"[錯誤] 下載失敗（{e2}）"


# ── 查詢單一車牌 ──────────────────────────────────────────────────────
async def query_plate(page, plate_raw: str, output_dir: Path) -> str:
    """
    輸入車牌（去除 -），查詢並依結果筆數處理。
    回傳結果描述字串。
    """
    plate_raw = str(plate_raw).strip()
    if not plate_raw or plate_raw.lower() == "nan":
        return ""

    plate_query = plate_raw.replace("-", "").strip()

    try:
        # 若不在查詢頁則導回去（session 已在，不需重新登入）
        if URL not in page.url:
            await page.goto(URL, wait_until="networkidle", timeout=30000)

        # 填入車牌（fill 會自動清空再填入）
        input_el = page.locator("form#dataForm input[type='text']").first
        await input_el.wait_for(timeout=10000)
        await input_el.fill(plate_query)

        # 按查詢（btnBox 第一顆按鈕）
        query_btn = page.locator("div.btnBox button").first
        await query_btn.wait_for(timeout=10000)
        await query_btn.click()
        await page.wait_for_load_state("networkidle", timeout=20000)
        await page.wait_for_timeout(1000)

        count = await get_result_count(page)

        if count == 0:
            return "查無資料"

        if count > 1:
            return f"[異常] 查到 {count} 筆"

        # 1 筆：下載
        return await download_pdf(page, plate_raw, output_dir)

    except Exception as e:
        return f"[錯誤] 查詢失敗：{e}"


# ── 寫回 Excel ────────────────────────────────────────────────────────
def write_back_excel(excel_path: Path, df: pd.DataFrame):
    wb = openpyxl.load_workbook(excel_path)
    ws = wb[SHEET_NAME]

    headers = [cell.value for cell in ws[1]]

    def get_or_create_col(col_name):
        if col_name in headers:
            return headers.index(col_name) + 1
        new_col = len(headers) + 1
        ws.cell(1, new_col, col_name)
        headers.append(col_name)
        return new_col

    col_head   = get_or_create_col("查詢結果（車頭）")
    col_tail   = get_or_create_col("查詢結果（車尾）")
    col_remark = get_or_create_col("備註")

    for i, row in df.iterrows():
        excel_row = i + 2
        ws.cell(excel_row, col_head,   row["查詢結果（車頭）"])
        ws.cell(excel_row, col_tail,   row["查詢結果（車尾）"])
        ws.cell(excel_row, col_remark, row["備註"])

    try:
        wb.save(excel_path)
        return excel_path
    except PermissionError:
        sys.exit(f"[錯誤] 檔案被 Excel 開著，請關閉後重新執行：{excel_path.name}")


# ── 主程式 ──────────────────────────────────────────────────────────
async def main():
    excel_path = find_today_excel()
    print(f"[開始] 來源檔案：{excel_path.name}")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    df = pd.read_excel(excel_path, sheet_name=SHEET_NAME, dtype=str)
    df["查詢結果（車頭）"] = ""
    df["查詢結果（車尾）"] = ""
    df["備註"] = ""

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)   # headless=True 可隱藏視窗
        context = await browser.new_context(accept_downloads=True)
        page    = await context.new_page()

        page = await login(page)  # login 回傳 GPS 系統的新分頁

        total = len(df)
        for idx, row in df.iterrows():
            客代 = str(row.get("客代", "")).strip()
            車頭 = str(row.get("車牌號碼（車頭）", "")).strip()
            車尾 = str(row.get("車牌號碼（車尾）", "")).strip()
            oa301車牌 = str(row.get("OA301車牌", "")).strip()
            安裝位置 = str(row.get("安裝位置", "")).strip()

            print(f"\n[{idx+1}/{total}] 客代 {客代}")

            notes = []

            def plate_mismatch(sheets_plate, oa301_plate):
                """比對時忽略 '-'，只有真正不同才觸發後備查詢"""
                return sheets_plate.replace("-", "").upper() != oa301_plate.replace("-", "").upper()

            # 查車頭
            if 車頭 and 車頭 != "nan":
                print(f"  ├ 車頭 {車頭} ... ", end="", flush=True)
                r = await query_plate(page, 車頭, OUTPUT_DIR)
                print(r)
                # 後備：OA301車牌對應車頭，且與Sheets車牌實質不同
                if r == "查無資料" and oa301車牌 and oa301車牌 != "nan" and "頭" in 安裝位置 and plate_mismatch(車頭, oa301車牌):
                    print(f"  ├ 後備(OA301) {oa301車牌} ... ", end="", flush=True)
                    r2 = await query_plate(page, oa301車牌, OUTPUT_DIR)
                    print(r2)
                    if r2 != "查無資料":
                        r = r2
                        notes.append(f"車頭：Sheets車牌({車頭})查無，改用OA301車牌({oa301車牌})查詢成功")
                    else:
                        notes.append(f"車頭：Sheets車牌({車頭})與OA301車牌({oa301車牌})皆查無資料")
                df.at[idx, "查詢結果（車頭）"] = r

            # 查車尾
            if 車尾 and 車尾 != "nan":
                print(f"  └ 車尾 {車尾} ... ", end="", flush=True)
                r = await query_plate(page, 車尾, OUTPUT_DIR)
                print(r)
                # 後備：OA301車牌對應車尾，且與Sheets車牌實質不同
                if r == "查無資料" and oa301車牌 and oa301車牌 != "nan" and "尾" in 安裝位置 and plate_mismatch(車尾, oa301車牌):
                    print(f"  └ 後備(OA301) {oa301車牌} ... ", end="", flush=True)
                    r2 = await query_plate(page, oa301車牌, OUTPUT_DIR)
                    print(r2)
                    if r2 != "查無資料":
                        r = r2
                        notes.append(f"車尾：Sheets車牌({車尾})查無，改用OA301車牌({oa301車牌})查詢成功")
                    else:
                        notes.append(f"車尾：Sheets車牌({車尾})與OA301車牌({oa301車牌})皆查無資料")
                df.at[idx, "查詢結果（車尾）"] = r

            # 備註：收集異常 + 後備查詢說明
            for col in ["查詢結果（車頭）", "查詢結果（車尾）"]:
                val = df.at[idx, col]
                if "[異常]" in str(val) or "[錯誤]" in str(val):
                    notes.append(f"{col}：{val}")
            df.at[idx, "備註"] = "；".join(notes)

        await browser.close()

    # 寫回 Excel
    print("\n[寫入] 寫回 Excel ...", end=" ")
    saved_path = write_back_excel(excel_path, df)
    print("完成")

    # ── 統計 ──
    all_results = list(df["查詢結果（車頭）"]) + list(df["查詢結果（車尾）"])
    downloaded  = sum(1 for v in all_results if "[OK]" in str(v))
    no_result   = sum(1 for v in all_results if "查無資料" in str(v))
    abnormal    = sum(1 for v in all_results if "[異常]" in str(v))
    failed      = sum(1 for v in all_results if "[錯誤]" in str(v))

    summary = f"""
══════════════════════════════════════
  處理結果
══════════════════════════════════════
  處理車輛數：{total} 筆
  成功下載：  {downloaded} 個 PDF
  查無資料：  {no_result} 筆
  異常（多筆）：{abnormal} 筆
  查詢失敗：  {failed} 筆
──────────────────────────────────────
  PDF 存放：  {OUTPUT_DIR}
  結果寫回：  {saved_path.name}
══════════════════════════════════════
"""
    print(summary)


if __name__ == "__main__":
    check_env()
    asyncio.run(main())
