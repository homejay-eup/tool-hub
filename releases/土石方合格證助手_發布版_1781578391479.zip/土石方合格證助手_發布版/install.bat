﻿@echo off
chcp 65001 > nul
title 土石方合格證助手 — 安裝程式
cd /d "%~dp0"

echo ================================================
echo   土石方合格證助手  初次安裝
echo ================================================
echo.

:: ── 步驟 1：檢查 Python ──────────────────────────
echo [1/4] 檢查 Python...
python --version > nul 2>&1
if errorlevel 1 (
    echo       Python 未安裝，嘗試自動安裝中...
    echo       （需要網路連線，約需 1-2 分鐘）
    echo.
    winget install -e --id Python.Python.3.11 --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo.
        echo [錯誤] 自動安裝失敗。
        echo        請手動到以下網址下載並安裝 Python 3.11：
        echo        https://www.python.org/downloads/
        echo        安裝時請勾選「Add Python to PATH」
        echo.
        pause
        exit /b 1
    )
    echo       Python 安裝完成！
    echo.
    :: 重新整理環境變數
    call refreshenv > nul 2>&1
    python --version > nul 2>&1
    if errorlevel 1 (
        echo [提示] 請關閉此視窗，重新開啟後再執行 install.bat
        pause
        exit /b 1
    )
)
for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo       已找到 %%v
echo.

:: ── 步驟 2：安裝 Python 套件 ─────────────────────
echo [2/4] 安裝 Python 套件（約 1-3 分鐘）...
echo.
python -m pip install --upgrade pip --quiet
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [錯誤] 套件安裝失敗，請確認網路連線後重試。
    pause
    exit /b 1
)
echo.
echo       套件安裝完成！
echo.

:: ── 步驟 3：下載 Playwright 瀏覽器 ───────────────
echo [3/4] 下載自動化瀏覽器 Chromium（約 150MB，需要 2-5 分鐘）...
echo.
python -m playwright install chromium
if errorlevel 1 (
    echo.
    echo [錯誤] Chromium 下載失敗，請確認網路連線後重試。
    pause
    exit /b 1
)
echo.
echo       Chromium 下載完成！
echo.

:: ── 步驟 4：完成 ─────────────────────────────────
echo [4/4] 安裝完成！
echo.
echo ================================================
echo   所有元件已安裝完畢
echo.
echo   接下來請：
echo   1. 閱讀「安裝說明.md」完成 Google 帳號授權
echo   2. 之後每次使用，雙擊「run.bat」即可
echo ================================================
echo.
pause
