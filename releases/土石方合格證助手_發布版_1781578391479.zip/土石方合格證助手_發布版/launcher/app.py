"""
launcher/app.py
土石方合格證助手 — 本地 Web 啟動器

啟動方式：run.bat 或 python launcher/app.py
瀏覽器開啟：http://localhost:5000
"""

import json
import os
import subprocess
import sys
from pathlib import Path

from flask import Flask, Response, render_template, request, stream_with_context

app = Flask(__name__)

PROJECT_DIR = Path(__file__).resolve().parents[1]
SCRIPTS_DIR = PROJECT_DIR / "_執行腳本" / "scripts"

STEPS = [
    {"id": 1, "name": "下載 OA301 已核可清單",    "script": "download_oa301.py"},
    {"id": 2, "name": "比對 + 回填 Sheets 資料",  "script": "process.py"},
    {"id": 3, "name": "查詢 OA401 + 下載 PDF",    "script": "query_gps_verify.py"},
    {"id": 4, "name": "依序列印 PDF",              "script": "print_pdf.py"},
]
STEP5 = {"id": 5, "name": "寄送後回寫 Google Sheets", "script": "update_sheets_after_shipping.py"}


def _subprocess_env():
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def run_script(script_name, extra_args=None):
    """執行腳本，以 generator 逐行 yield (event, data)"""
    script_path = SCRIPTS_DIR / script_name
    cmd = [sys.executable, "-u", str(script_path)] + (extra_args or [])

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            cwd=str(PROJECT_DIR),
            env=_subprocess_env(),
        )

        for line in proc.stdout:
            yield ("log", line.rstrip())

        proc.wait()
        yield ("exit", str(proc.returncode))

    except Exception as exc:
        yield ("error", str(exc))
        yield ("exit", "1")


def sse(event_type, **kwargs):
    payload = {"type": event_type, **kwargs}
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


def _sse_headers():
    return {"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}


# ── 路由 ──────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", steps=STEPS, step5=STEP5)


@app.route("/stream/steps")
def stream_steps():
    """步驟 1–4 依序執行，失敗時跳過繼續"""

    def generate():
        for step in STEPS:
            yield sse("step_start", id=step["id"])

            success = True
            logs = []
            for event, data in run_script(step["script"]):
                if event == "log":
                    logs.append(data)
                    yield sse("log", id=step["id"], text=data)
                elif event == "exit":
                    success = (data == "0")
                elif event == "error":
                    success = False
                    yield sse("log", id=step["id"], text=f"[系統錯誤] {data}")

            if not success and step["id"] == 1:
                if any("查到 0 筆" in line for line in logs):
                    yield sse("no_work")
                    return

            status = "success" if success else "fail"
            yield sse("step_done", id=step["id"], status=status)

        yield sse("steps_1_4_complete")

    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers=_sse_headers())


@app.route("/stream/step5/preview")
def stream_step5_preview():
    """步驟 5：只顯示預覽，不執行寫入"""
    date = request.args.get("date", "").strip()
    if not date:
        def err():
            yield sse("log", id=5, text="[錯誤] 未提供寄送日期")
            yield sse("step_done", id=5, status="fail")
        return Response(stream_with_context(err()), mimetype="text/event-stream",
                        headers=_sse_headers())

    def generate():
        yield sse("step_start", id=5)
        success = True
        for event, data in run_script(STEP5["script"], ["--date", date, "--preview-only"]):
            if event == "log":
                yield sse("log", id=5, text=data)
            elif event == "exit":
                success = (data == "0")
            elif event == "error":
                success = False
                yield sse("log", id=5, text=f"[系統錯誤] {data}")

        if success:
            yield sse("preview_done", id=5)
        else:
            yield sse("step_done", id=5, status="fail")

    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers=_sse_headers())


@app.route("/stream/step5/execute")
def stream_step5_execute():
    """步驟 5：確認後正式執行"""
    date = request.args.get("date", "").strip()
    if not date:
        def err():
            yield sse("log", id=5, text="[錯誤] 未提供寄送日期")
            yield sse("step_done", id=5, status="fail")
        return Response(stream_with_context(err()), mimetype="text/event-stream",
                        headers=_sse_headers())

    def generate():
        success = True
        for event, data in run_script(STEP5["script"], ["--date", date, "--yes"]):
            if event == "log":
                yield sse("log", id=5, text=data)
            elif event == "exit":
                success = (data == "0")
            elif event == "error":
                success = False
                yield sse("log", id=5, text=f"[系統錯誤] {data}")

        status = "success" if success else "fail"
        yield sse("step_done", id=5, status=status)

    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers=_sse_headers())


@app.route("/api/today-status")
def today_status():
    """檢查今天是否已執行過（_已核可清單/ 有今天的 xlsx）"""
    from datetime import date as _date
    today_str = _date.today().strftime("%Y%m%d")
    out_dir = PROJECT_DIR / "_已核可清單"
    exists = out_dir.exists() and any(out_dir.glob(f"*{today_str}*.xlsx"))
    return {"exists": exists, "date": today_str}


@app.route("/api/xlsx-files")
def xlsx_files():
    """列出可供比對的 xlsx 檔案清單"""
    src_dir  = PROJECT_DIR / "_國土署匯出檔"
    arch_dir = src_dir / "archived"

    def list_dir(folder):
        if not folder.exists():
            return []
        return [
            f.name for f in sorted(
                (x for x in folder.glob("*.xlsx") if not x.name.startswith("~$")),
                key=lambda x: x.stat().st_mtime, reverse=True
            )
        ]

    return {"current": list_dir(src_dir), "archived": list_dir(arch_dir)}


@app.route("/stream/step/<int:step_id>")
def stream_single_step(step_id):
    """單步執行（步驟 1–4）"""
    step = next((s for s in STEPS if s["id"] == step_id), None)
    if not step:
        def _err():
            yield sse("log", id=step_id, text=f"[錯誤] 找不到步驟 {step_id}")
            yield sse("step_done", id=step_id, status="fail")
        return Response(stream_with_context(_err()), mimetype="text/event-stream",
                        headers=_sse_headers())

    extra_args = []
    if step_id == 2:
        src_dir  = PROJECT_DIR / "_國土署匯出檔"
        arch_dir = src_dir / "archived"
        curr = request.args.get("curr", "").strip()
        prev = request.args.get("prev", "").strip()
        if curr:
            extra_args += ["--curr", str(src_dir / curr)]
        if prev:
            extra_args += ["--prev", str(arch_dir / prev)]

    def generate():
        yield sse("step_start", id=step_id)
        success = True
        logs = []
        for event, data in run_script(step["script"], extra_args):
            if event == "log":
                logs.append(data)
                yield sse("log", id=step_id, text=data)
            elif event == "exit":
                success = (data == "0")
            elif event == "error":
                success = False
                yield sse("log", id=step_id, text=f"[系統錯誤] {data}")

        if not success and step_id == 1:
            if any("查到 0 筆" in line for line in logs):
                yield sse("no_work")
                return

        yield sse("step_done", id=step_id, status="success" if success else "fail")

    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers=_sse_headers())


if __name__ == "__main__":
    print("土石方合格證助手啟動中...")
    print("請在瀏覽器開啟：http://localhost:5000")
    print("按 Ctrl+C 關閉\n")
    app.run(debug=False, host="127.0.0.1", port=5000, threaded=True)
