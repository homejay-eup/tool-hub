﻿@echo off
chcp 65001 > nul
title 土石方合格證助手
cd /d "%~dp0"

:: 檢查 Python
python --version > nul 2>&1
if errorlevel 1 (
    echo [錯誤] 找不到 Python，請先執行 install.bat
    pause
    exit /b 1
)

:: 檢查 Flask
python -c "import flask" > nul 2>&1
if errorlevel 1 (
    echo [錯誤] 套件未安裝，請先執行 install.bat
    pause
    exit /b 1
)

echo.
echo  土石方合格證助手 啟動中...
echo  瀏覽器將自動開啟
echo.
echo  關閉工具請按 Ctrl+C
echo.

start /b cmd /c "timeout /t 2 /nobreak > nul & start http://localhost:5000"

python launcher\app.py

echo.
echo  工具已關閉。
pause
